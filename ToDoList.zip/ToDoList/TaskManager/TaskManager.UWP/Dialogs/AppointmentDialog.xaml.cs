﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TaskManager.Library;
using TaskManager.Library.Models;
using TaskManager.Library.Utilities;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Content Dialog item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace TaskManager.UWP.Library.Dialogs
{
    public sealed partial class AppointmentDialog : ContentDialog
    {
        private ObservableCollection<ItemBase> taskList;

        public AppointmentDialog(ObservableCollection<ItemBase> taskList)
        {
            InitializeComponent();
            DataContext = new Appointment();
            this.taskList = taskList;
        }

        public AppointmentDialog(ObservableCollection<ItemBase> taskList, Appointment task)
        {
            InitializeComponent();
            DataContext = task;
            this.taskList = taskList;
        }

        private async void ContentDialog_PrimaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
            var handler = new WebRequestHandler();

            var taskToEdit = DataContext as Appointment;
            if (taskToEdit.AttendeeInput != null)
            {
                List<string> list = new List<string>(Regex.Split(taskToEdit.AttendeeInput, "\r"));
                taskToEdit.Attendees = list;
            }
            else
                taskToEdit.Attendees = new List<string>();

            //await handler.Post("http://localhost:31590/Appointment/AddOrUpdate", taskToEdit);
            var serverSide = JsonConvert.DeserializeObject<ItemBase>(handler.Post("http://localhost:31590/Appointment/AddOrUpdate", taskToEdit).Result);

            TaskHelper.AddOrEdit(taskList, serverSide);

        }

        private void ContentDialog_SecondaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
        }

        private void TextBox_OnBeforeTextChanging(TextBox sender,
                                         TextBoxBeforeTextChangingEventArgs args)
        {
            args.Cancel = args.NewText.Any(c => !char.IsDigit(c));
        }
    }
}
