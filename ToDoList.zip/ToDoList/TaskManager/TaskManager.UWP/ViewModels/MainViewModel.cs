﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using TaskManager.UWP.Library.Dialogs;
using TaskManager.Library.Models;
using TaskManager.Library;
using TaskManager.Library.Utilities;

namespace TaskManager.UWP.Library.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public ItemBase SelectedTask { get; set; }

        public string Query { get; set; }

        public static Constants.Selection UserSelection;

        public ObservableCollection<ItemBase> TaskList { get; set; }

        private ObservableCollection<ItemBase> filteredTaskList;

        public WebRequestHandler webRequestHandler = new WebRequestHandler();

        public ObservableCollection<ItemBase> FilteredTaskList
        {
            get
            {
                filteredTaskList = TaskHelper.RefreshedList(filteredTaskList,TaskList,UserSelection,Query);
                return filteredTaskList;
            }
        }

        public MainViewModel()
        {
            UserSelection = Constants.Selection.AllTasks;
            TaskList = new ObservableCollection<ItemBase>();

            TaskList = TaskHelper.GetAllAsync(webRequestHandler);
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public async Task Remove()
        {

            if (SelectedTask == null)
                return;

            await TaskHelper.Remove(SelectedTask,webRequestHandler);

            var itemToEdit = TaskList.FirstOrDefault(i => i._id == SelectedTask._id);
            var index = TaskList.IndexOf(itemToEdit);
            TaskList.RemoveAt(index);
            
            NotifyPropertyChanged("SelectedTask");
            NotifyPropertyChanged("FilteredTaskList");

        }

        public async Task CompleteTask()
        {
            if (SelectedTask == null || !(SelectedTask is Tasks))
                return;

            await TaskHelper.Complete(TaskList,SelectedTask as Tasks,webRequestHandler);
            NotifyPropertyChanged("SelectedTask");
            NotifyPropertyChanged("FilteredTaskList");

        }

        public async Task EditTask()
        {
            if (SelectedTask == null)
                return;
            
            if (SelectedTask is Tasks)
            {
                var diag = new TaskDialog(TaskList,SelectedTask as Tasks);
                NotifyPropertyChanged("SelectedTask");
                await diag.ShowAsync();
            }
            else
            {
                var diag = new AppointmentDialog(TaskList,SelectedTask as Appointment);
                NotifyPropertyChanged("SelectedTask");
                await diag.ShowAsync();
            }

            NotifyPropertyChanged("FilteredTaskList");


        }

        public async Task AddNew()
        {
            var showDiag = new TypeOfTask();
            await showDiag.ShowAsync();
            if (TypeOfTask.typeOfTask.Equals("task"))
            {
                var diag = new TaskDialog(TaskList);
                await diag.ShowAsync();
            }
            else
            {
                var diag = new AppointmentDialog(TaskList);
                await diag.ShowAsync();
            }

            NotifyPropertyChanged("FilteredTaskList");


        }

        public void Search()
        {
            UserSelection = Constants.Selection.Search;
            NotifyPropertyChanged("FilteredTaskList");
           
        }

        public void SortAscending()
        {
            UserSelection = Constants.Selection.SortAscending;
            NotifyPropertyChanged("FilteredTaskList");
        }

        public void SortDescending()
        {
            UserSelection = Constants.Selection.SortDescending;
            NotifyPropertyChanged("FilteredTaskList");
        }

        public void ShowAllTasks()
        {
            Query = "";
            UserSelection = Constants.Selection.AllTasks;
            NotifyPropertyChanged("FilteredTaskList");
        }

        public void ShowOutstandingTasks()
        {
            UserSelection = Constants.Selection.OutstandingTasks;
            NotifyPropertyChanged("FilteredTaskList");
        }
    }
}
