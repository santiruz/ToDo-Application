﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManager.Library.Models;

namespace TaskManager.Library.Utilities
{
    public class ItemJsonConverter : JsonCreationConverter<ItemBase>
    {

        protected override ItemBase Create(Type objectType, JObject jObject)
        {
            if (jObject == null) throw new ArgumentNullException("jObject");

            if (jObject["IsCompleted"] != null || jObject["isCompleted"] != null)
            {
                return new Tasks();
            }
            else if (jObject["Attendees"] != null || jObject["attendees"] != null)
            {
                return new Appointment();
            }
            else
            {
                return new ItemBase();
            }
        }
    }
}
