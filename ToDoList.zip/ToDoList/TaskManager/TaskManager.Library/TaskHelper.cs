﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManager.Library.Models;
using TaskManager.Library.Utilities;

namespace TaskManager.Library
{
    public static class TaskHelper
    {

        public static ObservableCollection<ItemBase> RefreshedList(ObservableCollection<ItemBase> filteredTaskList,ObservableCollection<ItemBase> taskList, Constants.Selection userSelection, string query)
        {

            switch (userSelection)
            {
                case Constants.Selection.OutstandingTasks:
                    taskList = ShowAllOrOutstanding(filteredTaskList, true);
                    break;
                case Constants.Selection.AllTasks:
                    taskList = ShowAllOrOutstanding(taskList);
                    break;
                case Constants.Selection.Search:
                    //server-side search
                    taskList = Search(new WebRequestHandler(), query);
                    break;
                case Constants.Selection.SortAscending:
                    taskList = Sort(filteredTaskList, true);
                    break;
                case Constants.Selection.SortDescending:
                    taskList = Sort(filteredTaskList);
                    break;
                default:
                    break;
            }

            return taskList;
            
        }


        public static ObservableCollection<ItemBase> GetAllAsync(WebRequestHandler handler)
        {
            return JsonConvert.DeserializeObject<ObservableCollection<ItemBase>>(handler.Get("http://localhost:31590/Itembase").Result);
        }

        public static async Task Remove(ItemBase itembase, WebRequestHandler handler)
        {
            if(itembase is Tasks)
            {
                await handler.Delete("http://localhost:31590/Tasks/Delete", itembase as Tasks);

            }

            else
            {
                await handler.Delete("http://localhost:31590/Appointment/Delete", itembase as Appointment);

            }
        }


        public static ObservableCollection<ItemBase> ShowAllOrOutstanding(ObservableCollection<ItemBase> taskList,bool outStanding = false)
        {
            if (outStanding)
            {
                if (taskList == null)
                    return taskList;

                //filter outstanding

                var outStandingTaskList = taskList.Where(i => (i is Tasks) && !(i as Tasks).IsCompleted).ToList();
                if (outStandingTaskList.Count > 0)
                {
                    taskList = new ObservableCollection<ItemBase>(outStandingTaskList);
                }
            }

            //return main list

            return taskList;
        }


        public static void Modify(ObservableCollection<ItemBase> taskList, ItemBase taskToEdit, ItemBase type)
        {
            int i = taskList.IndexOf(type);

            if (i >= 0)
            {
                taskList.Remove(type);
                taskList.Insert(i, taskToEdit);
            }
            else
            {
                taskList.Add(taskToEdit);
            }
        }

        public static void AddOrEdit(ObservableCollection<ItemBase> taskList, ItemBase taskToEdit)
        {
            if(taskToEdit is Tasks)
            {
                var existsAsTask = taskList.FirstOrDefault(t => t._id == taskToEdit._id && (t is Tasks));
                Modify(taskList, taskToEdit, existsAsTask);
            }

            else
            {
                var existsAsAppointment = taskList.FirstOrDefault(t => t._id == taskToEdit._id && (t is Appointment));
                Modify(taskList, taskToEdit, existsAsAppointment);
            }

        }

        public static async Task Complete(ObservableCollection<ItemBase> taskList,Tasks selectedTask,WebRequestHandler handler)
        {
            //already complete
            if (selectedTask.IsCompleted)
                return;

            var taskToEdit = selectedTask;
            taskToEdit.IsCompleted = true;

            AddOrEdit(taskList, taskToEdit);
            await handler.Post("http://localhost:31590/Tasks/AddOrUpdate", taskToEdit);
        }

        public static ObservableCollection<ItemBase> Sort(ObservableCollection<ItemBase> taskList, bool ascending = false)
        {
            List<ItemBase> sortedList;
            if (taskList.Count > 1)
            {
                if (ascending)
                    sortedList = taskList.OrderBy(t => int.Parse(t.Priority)).ToList();
                else
                    sortedList = taskList.OrderByDescending(t => int.Parse(t.Priority)).ToList();

                taskList = new ObservableCollection<ItemBase>(sortedList);
            }

            return taskList;

        }

        public static ObservableCollection<ItemBase> Search(WebRequestHandler handler,string query)
        {
            return JsonConvert.DeserializeObject<ObservableCollection<ItemBase>>(handler.Post("http://localhost:31590/Itembase/Search",query).Result);

        }


    }
}