﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using TaskManager.Library.Utilities;

namespace TaskManager.Library.Models
{
    [JsonConverter(typeof(ItemJsonConverter))]
    public class Appointment : ItemBase, INotifyPropertyChanged
    {
        public Appointment() : base()
        {

        }

        public event PropertyChangedEventHandler TaskPropertyChanged;


        [BsonElement("start")]
        private DateTime start = DateTime.Now;

        [BsonIgnore]
        public DateTimeOffset Start
        {
            get
            {
                return start;
            }
            set
            {
                start = value.DateTime;
                NotifyPropertyChanged();
            }
        }

        [BsonElement("stop")]
        private DateTime stop = DateTime.Now.AddDays(1);

        [BsonIgnore]
        public DateTimeOffset Stop
        {
            get
            {
                return stop;
            }
            set
            {
                stop = value.DateTime;
                NotifyPropertyChanged();
            }
        }


        [BsonIgnore]
        public string AttendeeInput
        {
            get; set;
        }

        [BsonElement("attendees")]
        public List<string> Attendees
        {
            get; set;
        }

        public override string ToString()
        {
            return $"[{Priority}]. {Name} - {Description} - Appointment";
        }

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            TaskPropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
