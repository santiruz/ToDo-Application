﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using TaskManager.Library.Utilities;

namespace TaskManager.Library.Models
{
    [JsonConverter(typeof(ItemJsonConverter))]
    public class Tasks : ItemBase
    {
        public Tasks() : base()
        {
            IsCompleted = false;
            //Deadline = DateTimeOffset.Now;
        }

        [BsonElement("deadline")]
        private DateTime deadline = DateTime.Now;

        [BsonIgnore]
        public DateTimeOffset Deadline
        {
            get
            {
                return deadline;
            }
            set
            {
                deadline = value.DateTime;
                NotifyPropertyChanged();
            }
        }

        [BsonElement("isCompleted"), BsonRequired]
        public bool IsCompleted { get; set; }


        //public DateTimeOffset Deadline { get; set; }

        public event PropertyChangedEventHandler TaskPropertyChanged;

        public override string ToString() 
        {
            string condition = IsCompleted ? "Complete" : "Incomplete";

            string deadline = Deadline.DateTime.ToShortDateString();

            return $"[{Priority}]. Task -  {Name} - {Description} - {condition} - {deadline}";
        }


        private void  NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            TaskPropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


    }


}
