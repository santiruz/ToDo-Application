﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManager.Library.Utilities;

namespace TaskManager.Library.Models
{
    [JsonConverter(typeof(ItemJsonConverter))]
    public class ItemBase : INotifyPropertyChanged
    {

        [BsonElement("name")]
        public string Name
        {
            get; set;
        }

        [BsonElement("description")]
        public string Description
        {
            get; set;
        }

        [BsonElement("priority")]
        public string Priority
        {
            get; set;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public ItemBase()
        {
            Priority = "10";
        }

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }


        }
    }

