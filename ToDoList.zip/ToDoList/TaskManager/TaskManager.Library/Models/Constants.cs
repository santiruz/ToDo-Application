﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManager.Library.Models
{
    public static class Constants
    {
        public enum Selection
        {
            OutstandingTasks,
            AllTasks,
            Search,
            SortAscending,
            SortDescending,
        }
    }
}