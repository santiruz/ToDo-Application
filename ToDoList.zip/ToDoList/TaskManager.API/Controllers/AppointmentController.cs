﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaskManager.Library.Models;
using TaskManager.API.Persistence;


namespace TaskManager.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AppointmentController : ControllerBase
    {
        private readonly ILogger<TasksController> _logger;

        private object _lock = new object();

        public AppointmentController(ILogger<TasksController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public List<Appointment> Get()
        {
            return Database.Current.Appointment.ToList();
        }


        [HttpPost("AddOrUpdate")]
        public ItemBase AddOrUpdate([FromBody] Appointment appointment)
        {

            Database.Current.AddOrUpdate(appointment);
            return appointment;
        }

        [HttpDelete("Delete")]
        public ItemBase Delete([FromBody] Appointment appointment)
        {
            Database.Current.Delete(appointment);
            return appointment;
        }
    }
}
