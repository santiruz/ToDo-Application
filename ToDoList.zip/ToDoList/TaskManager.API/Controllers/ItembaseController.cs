﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaskManager.Library.Models;
using TaskManager.API.Persistence;
using System.Collections.ObjectModel;

namespace TaskManager.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ItembaseController : ControllerBase
    {
        private readonly ILogger<ItembaseController> _logger;

        private object _lock;

        public ItembaseController(ILogger<ItembaseController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public List<ItemBase> Get()
        {
            var tasks = new ObservableCollection<ItemBase>(Database.Current.Tasks.Where(i => i != null));

            var appointments = new ObservableCollection<ItemBase>(Database.Current.Appointment.Where(i => i != null));


            return tasks.Union(appointments).OrderBy(t => t._id).ToList(); 
        }

        [HttpPost("Search")]
        public List<ItemBase> Search([FromBody] string query)
        {
            var taskList = Get();

            if (taskList.Count > 0 && !string.IsNullOrWhiteSpace(query))
            {
                var searchTerm = query.ToUpper();

                //find where name or description matches within task list
                var matchedWordsList = taskList
                    .Where(
                    i => i.Name.ToUpper().Contains(searchTerm)
                || i.Description.ToUpper().Contains(searchTerm)
                            ).ToList();

                //find where attendees name matches within appointmnet task list
                var matchedWordListAppoint = taskList
                    .Where(
                    t => (t is Appointment)
                    && (t as Appointment).Attendees
                    .Any(i => i
                    .ToUpper()
                    .Contains(searchTerm)))
                    .ToList();

                // if found via name and description print
                if (matchedWordsList.Count > 0)
                {
                    if (matchedWordListAppoint.Count > 0)
                        taskList = matchedWordsList.Union(matchedWordListAppoint).ToList();
                    else
                        taskList = matchedWordsList;
                }

                // if found via appointment attendee name print
                else if (matchedWordListAppoint.Count > 0)
                    taskList = matchedWordListAppoint;
            }

            return taskList;

        }

    }
}
