﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaskManager.Library.Models;
using TaskManager.API.Persistence;


namespace TaskManager.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TasksController : ControllerBase
    {
        private readonly ILogger<TasksController> _logger;

        public TasksController(ILogger<TasksController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public List<Tasks> Get()
        {
            return Database.Current.Tasks.ToList();
        }

        [HttpPost("AddOrUpdate")]
        public ItemBase AddOrUpdate([FromBody] Tasks tasks)
        {

            Database.Current.AddOrUpdate(tasks);
            return tasks;
        }


        [HttpDelete("Delete")]
        public ItemBase Delete([FromBody] Tasks tasks)
        {

            Database.Current.Delete(tasks);
            return tasks;
        }
    }
}
