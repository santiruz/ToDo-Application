﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TaskManager.Library.Models;

namespace TaskManager.API.Persistence
{
    public class Database
    {
        private IMongoDatabase _database;

        private static Database instance;
        public static Database Current
        {
            get
            {
                if (instance == null)
                {
                    var settings = MongoClientSettings.FromConnectionString("mongodb+srv://santiruz:Svk4DsMqfVjwd4kv@cluster0.z6jlw.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"); 
                    var client = new MongoClient(settings);
                    var _db = client.GetDatabase("ToDoList");
                    instance = new Database(_db);
                }

                return instance;
            }
        }

        public void AddOrUpdate(ItemBase item)
        {
            if (string.IsNullOrEmpty(item._id))
            {
                item._id = ObjectId.GenerateNewId().ToString();
            }

            //mapping for collections
            IMongoCollection<BsonDocument> collection;
            ItemBase itemToPersist;
            if (item is Tasks)
            {
                collection = _database.GetCollection<BsonDocument>("Tasks");
                itemToPersist = item as Tasks;
            }
            else if (item is Appointment)
            {
                collection = _database.GetCollection<BsonDocument>("Appointments");
                itemToPersist = item as Appointment;
            }
            else
            {
                throw new TypeNotSupportedException(item.GetType().ToString());
            }


            collection.DeleteOne(Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(itemToPersist._id)));
            collection.InsertOne(itemToPersist.ToBsonDocument());
            return;
        }

        public void Delete(ItemBase item)
        {
            if (string.IsNullOrEmpty(item._id))
            {
                return;
            }

            //mapping for collections
            IMongoCollection<BsonDocument> collection;
            ItemBase itemToPersist;
            if (item is Tasks)
            {
                collection = _database.GetCollection<BsonDocument>("Tasks");
                itemToPersist = item as Tasks;
            }
            else if (item is Appointment)
            {
                collection = _database.GetCollection<BsonDocument>("Appointments");
                itemToPersist = item as Appointment;
            }
            else
            {
                throw new TypeNotSupportedException(item.GetType().ToString());
            }


            collection.DeleteOne(Builders<BsonDocument>.Filter.Eq("_id", ObjectId.Parse(itemToPersist._id)));

            return;
        }


        public List<Tasks> Tasks
        {
            get
            {
                var todoBson = _database.GetCollection<BsonDocument>("Tasks");
                var data = todoBson.Find(_ => true).ToList();
                var _todos = new List<Tasks>();
                foreach (var item in data)
                {
                    var json = item.ToJson();
                    var obj = BsonSerializer.Deserialize<Tasks>(item);
                    _todos.Add(obj);
                }
                return _todos;
            }

        }

        public List<Appointment> Appointment
        {
            get
            {
                var todoBson = _database.GetCollection<BsonDocument>("Appointments");
                var data = todoBson.Find(_ => true).ToList();
                var _appointment = new List<Appointment>();
                foreach (var item in data)
                {
                    var json = item.ToJson();
                    var obj = BsonSerializer.Deserialize<Appointment>(item);
                    _appointment.Add(obj);
                }
                return _appointment;
            }

        }


        private Database(IMongoDatabase db)
        {
            _database = db;
        }

        public class TypeNotSupportedException : Exception
        {
            private string _type;
            public TypeNotSupportedException(string type)
            {
                _type = type;
            }
            public override string Message => $"Attempt was made to persist an unsupported type: {_type}";
        }


    }
}
